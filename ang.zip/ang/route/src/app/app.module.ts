import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { ListComponent } from './list/list.component';
import { ImageComponent } from './image/image.component';
import { BookComponent } from './book/book.component';

const routes : Routes = [
	{
		path: '',
		redirectTo: 'items',
		pathMatch: 'full'
	},
	{
		path: 'items',
		component: ListComponent,
		children: [
			{
				path: 'image',
				component: ImageComponent
			},
			{
				path: 'image/:id',
				component: BookComponent
			},
		]
	}
] 

@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    ListComponent,
    ImageComponent,
    BookComponent
  ],
  imports: [
    BrowserModule,
	RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }