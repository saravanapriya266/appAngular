import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router'; 
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
	selected: number;
  constructor(private router: ActivatedRoute) { }

  ngOnInit() {
  console.log("\n Test");
  	this.router.paramMap.subscribe ( ( params: ParamMap) => {
		this.selected = +(params.get('id'));
      console.log(this.selected);
	});
  }

}
