import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent {
constructor(
  	private route: Router,
	private router: ActivatedRoute
  ){};
  
  BookMenu : object[] = [
  	{id:1,item:'abc'},
	{id:2,item:'def'}
  ];
  
  ImageMenu : object[] = [
   {id:5, item:'test'},
   {id:6, item: 'test1'}
  ];
  
  title = 'app';
  gotoList(id){
  	this.route.navigate(['items', id], {relativeTo: this.router});
  }
 
  gotoImage(id){
  	this.route.navigate(['image',id], {relativeTo: this.router});
  }

}
