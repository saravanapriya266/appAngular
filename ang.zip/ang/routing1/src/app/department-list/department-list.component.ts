import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-department-list',
  template: `
    <p>
      department-list works!
    </p>
	<div *ngFor = "let i of listItems">
		<a>{{i.item}}</a>
		<button (click)="onSelect(i)">{{i.item}}</button>
	</div>
  `,
  styles: []
})
export class DepartmentListComponent implements OnInit {

  constructor(
  	private route: Router,
	private router: ActivatedRoute
  ) {};
  
  listItems : object[] = [
  	{id:1, item: 'Test 1'},
	{id:2, item: 'Test 2'}
  ];

  ngOnInit() {
  }
  
  onSelect(listid) {
  	console.log(listid);
  	this.route.navigate(['/departments', listid.id])
  }

}
