import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'emp-detail',
  templateUrl: './emp-detail.component.html',
  styleUrls: ['./emp-detail.component.css']
})
export class EmpDetailComponent implements OnInit {
  employee;
  empId;
  constructor(private _employeeService: EmployeeService, private route: ActivatedRoute, private router: Router) { 
  }

  ngOnInit() {
    this._employeeService.getEmployee().subscribe(data => this.employee = data);
    // this.empId = parseInt(this.route.snapshot.paramMap.get('id'));
    // snapshot gets updated only once during initial load, 
    // during prevClick and nextClick, it wont get updated;
    this.route.paramMap.subscribe((param: ParamMap) => {
      this.empId = parseInt(param.get('id'));
    })
  }

  prevClick() {
    this.router.navigate(['../', this.empId - 1],{relativeTo:this.route});
  }

  nextClick() {
    this.router.navigate(['../', this.empId + 1],{relativeTo:this.route});
  }

  backClick() {
    this.router.navigate(['../',{id:this.empId}],{relativeTo:this.route});
  }

  contactClick() {
      this.router.navigate(['econtact'],{relativeTo:this.route});
  }

  exitClick(){
    this.router.navigate(['eexit'],{relativeTo:this.route});
  }
}
