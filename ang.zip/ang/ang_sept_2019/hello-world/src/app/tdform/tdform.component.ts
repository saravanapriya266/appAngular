import { Component, OnInit } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { User } from '../user';
import { EnrollmentserviceService } from '../enrollmentservice.service';
import { error } from '@angular/compiler/src/util';
@Component({
  selector: 'app-tdform',
  templateUrl: './tdform.component.html',
  styleUrls: ['./tdform.component.css']
})
export class TDformComponent implements OnInit {
  errorMsg: any;

  constructor(public _enrollmentService: EnrollmentserviceService) { }
  userModel = new User('priya',25,'');
  ngOnInit() {
  }
  Reg (formVal) {
    console.log("Form Val", formVal);
    console.log("User Model", this.userModel);
    this._enrollmentService.getData(this.userModel)
                           .subscribe(
                             data=>console.log("Success",data),
                             error=>this.errorMsg = error.statusText
                           );
  }
}
