export interface ObservableEmp {
    name:string,
    age:number
}