import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms'
import { userNameValidator } from '../../shared/user-name.validators';
import { passwordMatchCheck } from 'src/shared/password.validators';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})

/*
  Form Group
  SUb Form Group
  Load Data dynamically(setValue, patchValue)
  Change to Form Builers
  Simple Validation
  Custom Validation (user-name.validators.ts)
  Cross Validation (password.validators.ts)
  conditional validation
  Dynamic form Controls
*/
export class ReactiveFormComponent implements OnInit {

  constructor(private fb: FormBuilder) { }

  registrationForm : FormGroup;
  get userName (){
    return this.registrationForm.get('userName');
  }

  /* registrationForm = new FormGroup({
    'name': new FormControl('Priya'),
    'password':new FormControl(''),
    'confirmpassword': new FormControl(''),
    'address':new FormGroup({
      'pincode':new FormControl('638001'),
      'location':new FormControl('')
    })
  }) */

  
  
  loadData() {
    /* this.registrationForm.setValue({
      name:'saravana',
      password:'abc',
      confirmpassword:'abc',
      address:{
        pincode:'600119',
        location:'chennai'
      }
    }) */
    // Set value works only when we set all the attributes; else use patchValue
    this.registrationForm.patchValue({
      name:'saravana',
      password:'abc',
      confirmpassword:'abc',
    })
  }

  get alternativeEmails() {
    return this.registrationForm.get('alternativeEmails') as FormArray;
  }
  
  addAlternativeEmails() {
    this.alternativeEmails.push(this.fb.control(''));
  }

  ngOnInit() {
    //Form Build usage is better than FormGroup, hence the change
    this.registrationForm = this.fb.group({
      'userName':['priya',[Validators.required,Validators.minLength(5),userNameValidator(/admin/)]],
      'password':'',
      'confirmpassword': '',
      'address':this.fb.group({
        'pincode':'638001',
        'location':''
      }),
      'emailA':'',
      'promotion':'',
      'alternativeEmails': this.fb.array([])
    },{validator:passwordMatchCheck()});

    
    this.registrationForm.get('promotion').valueChanges
                        .subscribe(checkedValue => {
                          const email = this.registrationForm.get('emailA');
                          if(checkedValue) 
                            email.setValidators(Validators.required);
                          else
                            email.clearValidators();
                          email.updateValueAndValidity();
                        });
  };
  onSubmit(){

  }
}
