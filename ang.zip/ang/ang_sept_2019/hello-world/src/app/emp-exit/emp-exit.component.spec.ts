import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpExitComponent } from './emp-exit.component';

describe('EmpExitComponent', () => {
  let component: EmpExitComponent;
  let fixture: ComponentFixture<EmpExitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpExitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpExitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
