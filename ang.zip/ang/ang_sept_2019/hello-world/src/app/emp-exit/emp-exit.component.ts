import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-exit',
  templateUrl: './emp-exit.component.html',
  styleUrls: ['./emp-exit.component.css']
})
export class EmpExitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
