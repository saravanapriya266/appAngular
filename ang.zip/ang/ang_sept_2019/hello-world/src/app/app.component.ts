import { Component } from '@angular/core';
//import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hello-world';
  parentData = "parent";
  message = "";
  // myobserable = Observable.of(1,2,3);

  // myobsever = {
  //   next: x => console.log(`nex val + ${x}`),
  //   error: x => console.log(`error + ${x}`),
  //   complete: x => console.log(`completed + ${x}`)
  // }

  // myobserable.subscribe(myobsever);

}
