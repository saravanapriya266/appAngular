import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { EmpListComponent } from './emp-list/emp-list.component';
import { EmpDetailComponent } from './emp-detail/emp-detail.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EmpContactComponent } from './emp-contact/emp-contact.component';
import { EmpExitComponent } from './emp-exit/emp-exit.component';
import { TDformComponent } from './tdform/tdform.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';

const routes : Routes = [
    // {path:'',redirectTo:'/edetail',pathMatch:'prefix'},
    // {path:'',redirectTo:'/elist',pathMatch:'full'},
    // {path:'elist',component:EmpListComponent},
    // {path:'elist/:id',component:EmpDetailComponent},

    //Make navigation relative; if we want to change from elist to elist-list;
    //need to change in many places'
    {path:'',redirectTo:'/elist-list',pathMatch:'full'},
    {path:'elist-list',component:EmpListComponent},
    {
        path:'elist-list/:id',
        component:EmpDetailComponent,
        children:[
            {path:'econtact',component:EmpContactComponent},
            {path:'eexit',component:EmpExitComponent}
        ]
    },
    {path:'edetail',component:EmpDetailComponent},
    {path:'form',component:TDformComponent},
    {path:'rform',component:ReactiveFormComponent},
    {path:'**',component:PageNotFoundComponent}
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRoutingModule{}
export const RoutingComponent = [
                                    EmpListComponent,
                                    EmpDetailComponent,
                                    PageNotFoundComponent,
                                    EmpContactComponent,
                                    EmpExitComponent
                                ];
