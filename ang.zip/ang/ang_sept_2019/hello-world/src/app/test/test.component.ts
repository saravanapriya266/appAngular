import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  myId = "testId";
  isDisabled = true;
  success = 'success';
  name = "two way binding";
  multipleclass = {
    success: false,
    failure: true
  }
  greeting;
  testngIf = true;
  color="red";
  colors = ["red","blue","green"];
  constructor() { }

  ngOnInit() {
  }

  onClick(event) {
    console.log(event);
    this.greeting = "clicked text";
  }
  onClickTypeRef(inputRef) {
    console.log(inputRef.value);
  }

  @Input()
  public parentData;

  @Output() public childData = new EventEmitter();
  fireEvent() {
    this.childData.emit('child Data');
    console.log("firreEvent");
  }
}
