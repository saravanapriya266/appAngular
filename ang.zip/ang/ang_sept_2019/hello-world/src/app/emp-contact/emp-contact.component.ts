import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-contact',
  templateUrl: './emp-contact.component.html',
  styleUrls: ['./emp-contact.component.css']
})
export class EmpContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
