import { TestBed } from '@angular/core/testing';

import { EnrollmentserviceService } from './enrollmentservice.service';

describe('EnrollmentserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EnrollmentserviceService = TestBed.get(EnrollmentserviceService);
    expect(service).toBeTruthy();
  });
});
