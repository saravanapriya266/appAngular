import { Injectable } from '@angular/core';
import { HttpClient }  from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ObservableEmp } from './employeeInterface';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http: HttpClient) { }

  getEmployee():Observable<ObservableEmp[]> {
    return this.http.get<ObservableEmp[]>('assets/data/employee');
  }
}
