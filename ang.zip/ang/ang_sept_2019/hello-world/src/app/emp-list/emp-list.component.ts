import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  employee = [];
  selectedEmpId;
  constructor(private _employeeService: EmployeeService, private router: Router, private aroute: ActivatedRoute) { }

  ngOnInit() {
    this._employeeService.getEmployee().subscribe(data => this.employee = data);
    this.aroute.paramMap.subscribe((param:ParamMap) => {
      this.selectedEmpId = parseInt(param.get('id'));
    })
  }

  onSelect(emp) {
    this.router.navigate([emp.id],{relativeTo:this.aroute});
  }
}
