import { AbstractControl, ValidatorFn } from "@angular/forms";

/* export function userNameValidator(control: AbstractControl) : {[key:string]:any} | null {
    var valCheck = /admin/.test(control.value);
    return valCheck? { 'misMatch':{value:control.value}} : null; 
} */

export function userNameValidator(rgx: RegExp):ValidatorFn {
    return (control: AbstractControl) : {[key:string]:any} | null => {
        var valCheck = rgx.test(control.value);
        return valCheck? { 'misMatch':{value:control.value}} : null; 
    }
}