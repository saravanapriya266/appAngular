import { ValidatorFn, AbstractControl } from '@angular/forms';

export function passwordMatchCheck():ValidatorFn{
    return (control:AbstractControl): {[key:string]:boolean} | null => {
        let pwd = control.get('password');
        let cnfmPwd = control.get('confirmpassword');
        if(pwd.pristine || cnfmPwd.pristine)
            return null;
        return (pwd.value !== cnfmPwd.value) ? { 'misMatch':true } : null;
    }
}